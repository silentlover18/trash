class Item:
    def __init__(self, value, weight):
        self.value = value
        self.weight = weight
        self.ratio = value / weight  # Value to weight ratio

def fractional_knapsack(capacity, items):
    # Sort items by value to weight ratio in descending order
    items.sort(key=lambda x: x.ratio, reverse=True)

    total_value = 0  # Maximum value that can be carried
    for item in items:
        if capacity <= 0:  # If the capacity is full, break the loop
            break

        # If the item can be fully accommodated in the knapsack
        if item.weight <= capacity:
            total_value += item.value
            capacity -= item.weight
        else:  # Take the fraction of the remaining item
            total_value += item.ratio * capacity  # Add the value of the fraction
            capacity = 0  # The knapsack is now full

    return total_value

# Example usage
if __name__ == "__main__":
    n = int(input("Enter number of items: "))
    values = list(map(int, input("Enter values of items (space-separated): ").split()))
    weights = list(map(int, input("Enter weights of items (space-separated): ").split()))
    capacity = int(input("Enter maximum weight: "))

    # Create Item objects
    items = [Item(values[i], weights[i]) for i in range(n)]

    # Calculate maximum value
    max_value = fractional_knapsack(capacity, items)
    print(f'The maximum value of items that can be carried: {max_value:.2f}')
