public class FibonacciRecursive {
    // Recursive method to calculate Fibonacci
    public static int fibonacci(int n) {
        if (n <= 1) {
            return n; // Base case: fibonacci(0) = 0, fibonacci(1) = 1
        }
        return fibonacci(n - 1) + fibonacci(n - 2); // Recursive case
    }

    public static void main(String[] args) {
        int n = 10; // Example input
        System.out.println("Fibonacci of " + n + " (Recursive): " + fibonacci(n));
    }
}
